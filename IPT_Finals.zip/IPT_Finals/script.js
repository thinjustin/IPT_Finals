function handleCredentialResponse(response) {
    const data = parseJwt(response.credential);

    // Save login info
    localStorage.setItem('access_token', response.credential);
    localStorage.setItem('username', data.name);
    localStorage.setItem('userEmail', data.email);
    localStorage.setItem('userPicture', data.picture);

    // Update UI
    document.getElementById('welcomeMessage').textContent = `Welcome, ${data.name}!`;
    document.getElementById('userEmail').textContent = data.email;
    document.getElementById('userPicture').src = data.picture;
    document.getElementById('userSection').style.display = 'block';

    document.querySelector('.g_id_signin').style.display = 'none';
}

function parseJwt(token) {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(atob(base64).split('').map(c =>
        '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)
    ).join(''));
    return JSON.parse(jsonPayload);
}

function logout() {
    localStorage.clear();
    location.reload();
}

async function searchBooks() {
    const query = document.getElementById('searchInput').value.trim();
    const year = document.getElementById('yearInput').value.trim();
    const limit = document.getElementById('limitSelect').value;

    if (!query) {
        alert('Please enter a book title.');
        return;
    }

    let url = `https://openlibrary.org/search.json?q=${encodeURIComponent(query)}&limit=${limit}`;

    const response = await fetch(url);
    const data = await response.json();
    let books = data.docs || [];

    if (year !== '') {
        books = books.filter(book => {
            return book.first_publish_year && book.first_publish_year >= parseInt(year);
        });
    }

    displayBooks(books.slice(0, limit));
}

function displayBooks(books) {
    const container = document.getElementById('booksContainer');
    container.innerHTML = '';

    if (books.length === 0) {
        container.innerHTML = '<p>No books found.</p>';
        return;
    }

    books.forEach(book => {
        const div = document.createElement('div');
        div.className = 'book-card';

        const title = book.title || 'No Title';
        const author = (book.author_name && book.author_name.join(', ')) || 'Unknown Author';
        const imgSrc = book.cover_i ? 
            `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg` :
            'https://via.placeholder.com/150x200?text=No+Cover';

        div.innerHTML = `
            <img src="${imgSrc}" alt="Book Cover">
            <h3>${title}</h3>
            <p>${author}</p>
            <button class="bookmark-btn" onclick='bookmarkBook(${JSON.stringify(book)})'>Bookmark</button>
        `;

        container.appendChild(div);
    });
}

function bookmarkBook(book) {
    const token = localStorage.getItem('access_token');
    if (!token) {
        alert('You must be logged in to bookmark a book.');
        return;
    }

    let bookmarks = JSON.parse(localStorage.getItem('bookmarks')) || [];
    bookmarks.push(book);
    localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
    alert('Book bookmarked successfully!');
}

function viewBookmarks() {
    const bookmarks = JSON.parse(localStorage.getItem('bookmarks')) || [];
    displayBooks(bookmarks);
}
document.addEventListener('DOMContentLoaded', () => {
    // Load default books when the page is first opened
    loadDefaultBooks();
});

function loadDefaultBooks() {
    const defaultQuery = "bestsellers"; // you can change this to "fiction", "science", etc.
    const limit = document.getElementById('limitSelect').value;

    fetch(`https://openlibrary.org/search.json?q=${encodeURIComponent(defaultQuery)}&limit=${limit}`)
        .then(response => response.json())
        .then(data => {
            const books = data.docs || [];
            displayBooks(books.slice(0, limit));
        })
        .catch(error => {
            console.error('Error loading default books:', error);
        });
}
